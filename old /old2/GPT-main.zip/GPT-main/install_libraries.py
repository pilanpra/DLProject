def install_required_libraries():
    !pip install transformers
    !pip install torch
    !pip install datasets
