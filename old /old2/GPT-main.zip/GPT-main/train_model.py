def train_gpt2_model(trainer):
    trainer.train()
